// Task1: initiate app and run server at 3000

const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Parse JSON request bodies sent by the frontend.
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// The supplied build folder is named "Frontend" (capital F).
// Keep the original static-serving line below unchanged as requested.
app.use(express.static(path.join(__dirname, 'dist', 'Frontend')));

app.use(express.static(path.join(__dirname+'/dist/FrontEnd')));

// Task2: create mongoDB connection
// Set MONGODB_URI to your MongoDB Atlas connection string before starting the app.
const MONGODB_URI = process.env.MONGODB_URI;

mongoose.connect(MONGODB_URI || '')
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch((error) => {
    console.error('MongoDB connection failed:', error.message);
  });

// Keep the model/collection name consistent with the employee API.
const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  location: { type: String, required: true, trim: true },
  position: { type: String, required: true, trim: true },
  salary: { type: Number, required: true }
}, { versionKey: false });

const Employee = mongoose.models.Employee ||
  mongoose.model('Employee', employeeSchema, 'employees');

function validateEmployee(body) {
  const { name, location, position, salary } = body || {};
  if (
    typeof name !== 'string' || !name.trim() ||
    typeof location !== 'string' || !location.trim() ||
    typeof position !== 'string' || !position.trim() ||
    salary === undefined || salary === null || salary === '' ||
    !Number.isFinite(Number(salary))
  ) {
    return 'name, location, position, and a numeric salary are required';
  }
  return null;
}

// Task 2: write api with error handling and appropriate api mentioned in the TODO below

//TODO: get data from db using api '/api/employeelist'
app.get('/api/employeelist', async (req, res) => {
  try {
    const employees = await Employee.find().lean();
    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({ message: 'Failed to retrieve employees', error: error.message });
  }
});

//TODO: get single data from db using api '/api/employeelist/:id'
app.get('/api/employeelist/:id', async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid employee id' });
    }
    const employee = await Employee.findById(req.params.id).lean();
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    res.status(200).json(employee);
  } catch (error) {
    res.status(500).json({ message: 'Failed to retrieve employee', error: error.message });
  }
});

//TODO: send data from db using api '/api/employeelist'
//Request body format:{name:'',location:'',position:'',salary:''}
app.post('/api/employeelist', async (req, res) => {
  try {
    const validationError = validateEmployee(req.body);
    if (validationError) {
      return res.status(400).json({ message: validationError });
    }
    const employee = await Employee.create({
      name: req.body.name.trim(),
      location: req.body.location.trim(),
      position: req.body.position.trim(),
      salary: Number(req.body.salary)
    });
    res.status(201).json(employee);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add employee', error: error.message });
  }
});

//TODO: delete a employee data from db by using api '/api/employeelist/:id'
app.delete('/api/employeelist/:id', async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid employee id' });
    }
    const employee = await Employee.findByIdAndDelete(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    res.status(200).json({ message: 'Employee deleted successfully', employee });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete employee', error: error.message });
  }
});

//TODO: Update a employee data from db by using api '/api/employeelist'
//Request body format:{name:'',location:'',position:'',salary:''}
app.put('/api/employeelist', async (req, res) => {
  try {
    const id = req.body && (req.body._id || req.body.id);
    if (!id || !mongoose.isValidObjectId(id)) {
      return res.status(400).json({ message: 'A valid employee id (_id or id) is required in the request body' });
    }
    const validationError = validateEmployee(req.body);
    if (validationError) {
      return res.status(400).json({ message: validationError });
    }
    const employee = await Employee.findByIdAndUpdate(
      id,
      {
        name: req.body.name.trim(),
        location: req.body.location.trim(),
        position: req.body.position.trim(),
        salary: Number(req.body.salary)
      },
      { new: true, runValidators: true }
    );
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    res.status(200).json(employee);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update employee', error: error.message });
  }
});

//! dont delete this code. it connects the front end file.
app.get('/*', function (req, res) {
    res.sendFile(path.join(__dirname + '/dist/Frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`Employee App server listening on port ${PORT}`);
});
