# Employee App Backend

## Setup
1. Install Node.js (LTS).
2. In this folder, run `npm install`.
3. In MongoDB Atlas, create a database user and allow your machine's IP address in Network Access.
4. Set `MONGODB_URI` to your Atlas connection string. Replace the password/database placeholders with your own values.
   - macOS/Linux: `export MONGODB_URI='mongodb+srv://<username>:<password>@<cluster-url>/employeeapp?retryWrites=true&w=majority'`
   - PowerShell: `$env:MONGODB_URI='mongodb+srv://<username>:<password>@<cluster-url>/employeeapp?retryWrites=true&w=majority'`
5. Start the server with `npm start` and open `http://localhost:3000`.

The API uses the MongoDB `employees` collection. Do not commit your Atlas connection string or database password to GitHub.
